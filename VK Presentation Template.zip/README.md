## VK Presentation Template

---
Simple, modern Beamer theme.

Not convinced? Have a look at the [demo slides](/demo_slides.pdf).

![Sample](images/demo_slides.png)
